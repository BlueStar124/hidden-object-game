# Bản web Vite (đã lưu trữ)

Bản web đầu tiên của game, dựng bằng Vite + DOM/CSS. Không còn được build hay deploy: game giờ là
bản Expo trong `app/` (iOS · Android · web), deploy bằng `vercel.json`.

Zip này là một dự án Vite **đầy đủ** — giao diện cùng lõi game nó dùng (`src/hooks`, `src/game`,
`src/levels`, `src/data`, `src/types`, `src/components/Sprites`), như ở commit 306f07e — trừ các
bức tranh, vẫn nằm trong repo.

## Chạy lại

1. Giải nén vào một thư mục trống.
2. Chép tranh: `app/assets/art/singapore/*.png` (trong repo) → `public/assets/scenes/` của thư mục
   vừa giải nén (giữ nguyên tên file).
3. Đổi tên `package.vite.json` thành `package.json`, rồi chạy `npm install`.
4. `npm run dev` → http://localhost:3000
