# Bản web Vite (đã lưu trữ)

Giao diện web cũ dựng bằng Vite + DOM/CSS. Không còn được build hay deploy: bản web chính thức
giờ là bản Expo trong `app/` (xem `vercel.json`).

Lõi game dùng chung (`src/hooks`, `src/game`, `src/levels`, `src/data`, `src/types`,
`src/components/Sprites/ObjectSprite.tsx` + `sprites.css`) vẫn nằm nguyên trong `src/` vì app đang dùng.

## Khôi phục

1. Giải nén file zip này ngay tại thư mục gốc của repo (giữ nguyên đường dẫn).
2. Thay `package.json` gốc bằng `package.vite.json` trong zip (có lại các script `dev`/`build`/`preview`
   và thư viện `vite`, `@vitejs/plugin-react`, `lucide-react`), rồi chạy `npm install`.
3. `npm run dev` → http://localhost:3000

Lưu ý: `useGame` đã đổi từ khi lưu trữ (có thêm `turn` cho hiệu ứng lật trang của app); `isTurning`
vẫn còn nên bản Vite vẫn chạy được.
